<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the portfolio as one client-only TanStack route whose page scroll drives a single React Three Fiber flight path (girl, camera, doors), with DOM overlays, because the journey must feel like one continuous flight.
- Keep portfolio facts and door destinations in a single content module, because in-world navigation and section copy must stay aligned.
- Keep social brand marks as local SVG paths, because the design needs recognizable icons without remote media or a large icon dependency.
