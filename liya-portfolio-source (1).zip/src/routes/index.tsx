import { createFileRoute } from "@tanstack/react-router";
import { PortfolioExperience } from "@/components/PortfolioExperience";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({ meta: [
    { title: "Liya Fathima | My Journey" },
    { name: "description", content: "Explore Liya Fathima's cinematic portfolio through a sky of floating islands and doors to her projects, skills and story." },
    { property: "og:title", content: "Liya Fathima | My Journey" },
    { property: "og:description", content: "A portfolio through the sky. Discover Liya's projects, skills, education and story." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: PortfolioExperience,
});
