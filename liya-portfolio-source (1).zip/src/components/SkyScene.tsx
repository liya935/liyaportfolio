import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { AdaptiveDpr, Billboard, Environment, Html, Lightformer, Preload, Sparkles, useTexture } from "@react-three/drei";
import { Suspense, useMemo, useRef, type MutableRefObject } from "react";
import * as THREE from "three";
import { destinations, JOURNEY_LENGTH, type DestinationId } from "@/lib/portfolio";
import { pathX, pathY, seeded } from "@/lib/flight-path";
import flyingImage from "@/assets/flying-liya.png";
import islandImage from "@/assets/portal-island.png";

type Props = {
  /** Target flight distance driven by scroll. */
  targetRef: MutableRefObject<number>;
  paused: boolean;
  enter: (id: DestinationId) => void;
};

const DOOR_SCALE = 6.8;

function archShape() {
  const s = new THREE.Shape();
  s.moveTo(-0.6, -1);
  s.lineTo(-0.6, 0.36);
  s.absarc(0, 0.36, 0.6, Math.PI, 0, true);
  s.lineTo(0.6, -1);
  s.lineTo(0.45, -1);
  s.lineTo(0.45, 0.36);
  s.absarc(0, 0.36, 0.45, 0, Math.PI, false);
  s.lineTo(-0.45, -1);
  s.closePath();
  return s;
}
function innerShape() {
  const s = new THREE.Shape();
  s.moveTo(-0.46, -0.98);
  s.lineTo(-0.46, 0.34);
  s.absarc(0, 0.34, 0.46, Math.PI, 0, true);
  s.lineTo(0.46, -0.98);
  s.closePath();
  return s;
}
const arch = archShape();
const inside = innerShape();

function makeCanvasTexture(draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void, w = 256, h = 256) {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  draw(canvas.getContext("2d")!, w, h);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function cloudTexture(seed: number) {
  const rand = seeded(seed);
  return makeCanvasTexture((ctx, w, h) => {
    for (let i = 0; i < 26; i++) {
      const x = w * (0.2 + rand() * 0.6);
      const y = h * (0.35 + rand() * 0.35);
      const r = w * (0.08 + rand() * 0.16);
      const g = ctx.createRadialGradient(x, y - r * 0.2, 0, x, y, r);
      const shade = 235 + Math.floor(rand() * 20);
      g.addColorStop(0, `rgba(255,${shade},${shade - 8},0.55)`);
      g.addColorStop(0.55, `rgba(240,244,250,0.28)`);
      g.addColorStop(1, "rgba(220,230,245,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    }
  }, 512, 256);
}

/* ---------- Doors ---------- */
function Portal({ item, enter }: { item: (typeof destinations)[number]; enter: Props["enter"] }) {
  const island = useTexture(islandImage);
  const pulse = useRef<THREE.Mesh>(null);
  const glow = useRef<THREE.Group>(null);
  const Icon = item.icon;
  const pos: [number, number, number] = [pathX(item.distance), pathY(item.distance) - 0.2, -item.distance];
  const click = (e: { stopPropagation: () => void }) => { e.stopPropagation(); enter(item.id); };
  const over = () => { document.body.style.cursor = "pointer"; };
  const out = () => { document.body.style.cursor = ""; };
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (glow.current) glow.current.position.y = Math.sin(t * 0.55 + item.distance) * 0.03;
    if (pulse.current) (pulse.current.material as THREE.MeshBasicMaterial).opacity = 0.08 + Math.sin(t * 1.7 + item.distance) * 0.04;
  });
  return (
    <group position={pos} scale={DOOR_SCALE}>
      <Billboard position={[0, -1.61, -0.55]}>
        <mesh scale={[2.7, 2.7, 1]}>
          <planeGeometry args={[1, 1]} />
          <meshBasicMaterial map={island} transparent depthWrite={false} toneMapped={false} />
        </mesh>
      </Billboard>
      <group ref={glow}>
        <mesh position={[0, 0, -0.035]} onClick={click} onPointerOver={over} onPointerOut={out}>
          <shapeGeometry args={[inside]} />
          <meshPhysicalMaterial color={item.color} emissive={item.color} emissiveIntensity={0.4} transparent opacity={0.3} roughness={0.12} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        <mesh ref={pulse} position={[0, 0, 0.012]}>
          <shapeGeometry args={[inside]} />
          <meshBasicMaterial color={item.color} transparent opacity={0.1} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
        <mesh position={[0, 0, 0.07]} onClick={click} onPointerOver={over} onPointerOut={out}>
          <extrudeGeometry args={[arch, { depth: 0.13, bevelEnabled: true, bevelThickness: 0.045, bevelSize: 0.035, bevelSegments: 3, curveSegments: 24 }]} />
          <meshStandardMaterial color="#596b78" emissive={item.color} emissiveIntensity={0.55} metalness={0.57} roughness={0.22} />
        </mesh>
        <mesh position={[0, -1, 0.1]}>
          <boxGeometry args={[1.4, 0.11, 0.34]} />
          <meshStandardMaterial color="#dce9ee" emissive={item.color} emissiveIntensity={0.36} metalness={0.4} roughness={0.32} />
        </mesh>
        <Sparkles count={14} scale={[1.8, 2.6, 0.8]} size={3} speed={0.3} color={item.color} />
        <Html transform center position={[0, 1.18, 0.2]} distanceFactor={2.2} style={{ pointerEvents: "none" }}>
          <div className="portal-label" style={{ color: item.color }}>
            <Icon size={25} strokeWidth={1.4} />
            <span>{item.title}</span>
          </div>
        </Html>
      </group>
    </group>
  );
}

/* ---------- Flight rig: the girl travels the path; the camera chases her ---------- */
function useFlutterMaterial(texture: THREE.Texture) {
  return useMemo(() => {
    const uniforms = { uTime: { value: 0 }, uSpeed: { value: 0 } };
    const mat = new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, toneMapped: false });
    mat.onBeforeCompile = (shader) => {
      shader.uniforms['uTime'] = uniforms.uTime;
      shader.uniforms['uSpeed'] = uniforms.uSpeed;
      shader.vertexShader = "uniform float uTime;\nuniform float uSpeed;\n" + shader.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        // Trailing edge (left: hair, dress hem, feet) ripples more than the leading arms.
        float trail = smoothstep(0.2, -0.5, position.x);
        float lower = smoothstep(0.1, -0.5, position.y);
        float amp = (0.012 + uSpeed * 0.02) * (trail + lower * 0.6);
        transformed.y += sin(uTime * 6.0 + position.x * 9.0) * amp;
        transformed.x += sin(uTime * 4.3 + position.y * 7.0) * amp * 0.6;
        // Gentle arm sway on the leading edge.
        float lead = smoothstep(0.1, 0.5, position.x);
        transformed.y += sin(uTime * 1.8) * 0.012 * lead;`,
      );
    };
    return { mat, uniforms };
  }, [texture]);
}

const TRAIL = 70;
const MAX_SPEED = 90; // world units / second — caps lurches on fast flings
const CAM_BACK = 9.5; // resting camera distance behind her
const CAM_MAX_LAG = 15; // furthest she can pull ahead before the camera must keep up

function FlightRig({ targetRef, paused, distanceRef }: Pick<Props, "targetRef" | "paused"> & { distanceRef: MutableRefObject<number> }) {
  const texture = useTexture(flyingImage);
  const { camera, size } = useThree();
  const girl = useRef<THREE.Group>(null);
  const body = useRef<THREE.Mesh>(null);
  const time = useRef(0);
  const vel = useRef(0);
  const camDist = useRef(distanceRef.current - CAM_BACK);
  const look = useMemo(() => new THREE.Vector3(), []);
  const lookSmooth = useMemo(() => new THREE.Vector3(), []);
  const camTarget = useMemo(() => new THREE.Vector3(), []);
  const first = useRef(true);
  const { mat, uniforms } = useFlutterMaterial(texture);
  const geom = useMemo(() => new THREE.PlaneGeometry(1, 1, 24, 24), []);
  // World-space trail: points stay where she has been, so her own movement through space is visible.
  const trail = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(TRAIL * 3);
    const col = new Float32Array(TRAIL * 3);
    for (let i = 0; i < TRAIL; i++) { const f = 1 - i / TRAIL; col.set([0.75 * f, 0.92 * f, 1 * f], i * 3); }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(col, 3));
    return g;
  }, []);
  const trailInit = useRef(false);
  const dot = useMemo(() => makeCanvasTexture((ctx, w, h) => {
    const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.35, "rgba(200,240,255,0.5)"); g.addColorStop(1, "rgba(200,240,255,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }, 64, 64), []);
  useFrame((_, rawDelta) => {
    const dt = Math.min(rawDelta, 0.05);
    if (!paused) time.current += dt;
    const t = time.current;
    // One continuous progress system: a critically-damped spring toward the scroll target.
    const k = 6;
    const err = targetRef.current - distanceRef.current;
    vel.current += (err * k * k * 0.25 - vel.current * k) * dt;
    vel.current = THREE.MathUtils.clamp(vel.current, -MAX_SPEED, MAX_SPEED);
    const d = distanceRef.current + vel.current * dt;
    distanceRef.current = d;
    const speed = Math.min(Math.abs(vel.current) / 25, 1);
    uniforms.uTime.value = t;
    uniforms.uSpeed.value += (speed - uniforms.uSpeed.value) * (1 - Math.exp(-3 * dt));

    const narrow = size.width < 700;
    // Even at rest she keeps gliding: a slow surge along the path plus sway and bob.
    const glide = Math.sin(t * 0.45) * 0.9;
    const gd = d + glide;
    const gx = pathX(gd) + Math.sin(t * 0.6) * 0.35;
    const gy = pathY(gd) + Math.sin(t * 1.5) * 0.22 + Math.sin(t * 0.7) * 0.1;
    if (girl.current) {
      girl.current.position.set(gx, gy, -gd);
      const bank = (pathX(gd + 4) - pathX(gd)) * -0.09;
      const climb = (pathY(gd + 4) - pathY(gd)) * 0.06;
      const targetZ = -0.08 + bank + Math.sin(t * 0.85) * 0.05 - uniforms.uSpeed.value * 0.07 + climb;
      girl.current.rotation.z += (targetZ - girl.current.rotation.z) * (1 - Math.exp(-4 * dt));
      girl.current.rotation.y = Math.sin(t * 0.5) * 0.08 + bank * 0.8;
    }
    if (body.current) {
      const s = narrow ? 1.6 : 2.1;
      body.current.scale.set(s * (1 + uniforms.uSpeed.value * 0.04), s * (1 + Math.sin(t * 3.2) * 0.012), 1);
    }

    // Trail: shift history back and add her current position (behind her feet).
    const arr = trail.attributes['position']!.array as Float32Array;
    const hx = gx - 0.7, hy = gy - 0.15, hz = -gd + 0.2;
    if (!trailInit.current) { for (let i = 0; i < TRAIL; i++) arr.set([hx, hy, hz], i * 3); trailInit.current = true; }
    arr.copyWithin(3, 0, (TRAIL - 1) * 3);
    arr[0] = hx; arr[1] = hy; arr[2] = hz;
    trail.attributes['position']!.needsUpdate = true;

    // Follow camera: it chases her on its own slower spring. While she speeds up she pulls ahead
    // (moving forward in frame); when she slows, the camera glides back in behind her.
    camDist.current += (d - CAM_BACK - camDist.current) * (1 - Math.exp(-1.6 * dt));
    camDist.current = THREE.MathUtils.clamp(camDist.current, d - CAM_MAX_LAG, d - CAM_BACK + 2);
    const camD = camDist.current;
    // Slowly drifting framing angle so she is seen weaving and banking across the frame.
    const offX = (narrow ? 0 : -2.6) + Math.sin(camD * 0.021) * 1.4;
    const offY = (narrow ? -1.6 : 1.1) + Math.sin(camD * 0.014 + 1) * 0.7;
    camTarget.set(pathX(camD) * 0.75 + pathX(d) * 0.25 + offX, pathY(camD) * 0.6 + pathY(d) * 0.3 + offY, -camD);
    if (first.current) { camera.position.copy(camTarget); first.current = false; }
    camera.position.lerp(camTarget, 1 - Math.exp(-3 * dt));
    look.set(pathX(d + 16) * 0.5 + pathX(d) * 0.5 + offX * 0.9, pathY(d + 16) * 0.4 + pathY(d) * 0.5 + offY - 0.4, -(d + 20));
    if (lookSmooth.lengthSq() === 0) lookSmooth.copy(look);
    lookSmooth.lerp(look, 1 - Math.exp(-2.5 * dt));
    camera.lookAt(lookSmooth);
  });
  return (
    <>
      <points geometry={trail} frustumCulled={false}>
        <pointsMaterial map={dot} size={0.22} vertexColors transparent opacity={0.85} blending={THREE.AdditiveBlending} depthWrite={false} sizeAttenuation />
      </points>
      <group ref={girl}>
        <mesh ref={body} geometry={geom} material={mat} renderOrder={2} />
        <Sparkles count={16} scale={[2.4, 0.8, 1.6]} position={[-0.8, -0.1, 0.8]} size={1.6} speed={paused ? 0 : 0.6} color="#a8eaff" />
      </group>
    </>
  );
}

/* ---------- Environment ---------- */
function Clouds() {
  const textures = useMemo(() => [cloudTexture(3), cloudTexture(11), cloudTexture(27)], []);
  const clouds = useMemo(() => {
    const rand = seeded(42);
    return Array.from({ length: 75 }, (_, i) => {
      const d = -20 + rand() * (JOURNEY_LENGTH + 120);
      const side = rand() < 0.5 ? -1 : 1;
      const x = pathX(d) + side * (16 + rand() * 40);
      const below = rand() < 0.55;
      const y = below ? pathY(d) - 12 - rand() * 14 : pathY(d) + 6 + rand() * 14;
      const w = 18 + rand() * 34;
      return { pos: [x, y, -d] as [number, number, number], w, h: w * (0.38 + rand() * 0.2), tex: i % 3, drift: 0.2 + rand() * 0.5, opacity: 0.55 + rand() * 0.4 };
    });
  }, []);
  const group = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    group.current?.children.forEach((c, i) => { c.position.x = clouds[i]!.pos[0] + Math.sin(clock.elapsedTime * 0.04 + i) * clouds[i]!.drift * 4; });
  });
  return <group ref={group}>
    {clouds.map((c, i) => <Billboard key={i} position={c.pos}>
      <mesh scale={[c.w, c.h, 1]}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial map={textures[c.tex]!} transparent opacity={c.opacity} depthWrite={false} fog />
      </mesh>
    </Billboard>)}
  </group>;
}

function Waterfall({ height }: { height: number }) {
  const tex = useMemo(() => {
    const t = makeCanvasTexture((ctx, w, h) => {
      for (let x = 0; x < w; x += 2) {
        const a = 0.25 + Math.random() * 0.55;
        const g = ctx.createLinearGradient(0, 0, 0, h);
        g.addColorStop(0, `rgba(235,248,255,${a})`);
        g.addColorStop(0.5, `rgba(200,232,250,${a * 0.6})`);
        g.addColorStop(1, `rgba(200,232,250,${a * 0.9})`);
        ctx.fillStyle = g;
        ctx.fillRect(x, 0, 1.5, h);
      }
    }, 64, 256);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return t;
  }, []);
  const fade = useMemo(() => makeCanvasTexture((ctx, w, h) => {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.7, "rgba(255,255,255,0.7)"); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }, 8, 128), []);
  useFrame((_, dt) => { tex.offset.y += Math.min(dt, 0.05) * 0.6; });
  return <mesh position={[0, -height / 2, 0]}>
    <planeGeometry args={[0.9, height]} />
    <meshBasicMaterial map={tex} alphaMap={fade} transparent depthWrite={false} side={THREE.DoubleSide} />
  </mesh>;
}

function Islands() {
  const island = useTexture(islandImage);
  const islands = useMemo(() => {
    const rand = seeded(7);
    return Array.from({ length: 30 }, () => {
      const d = 10 + rand() * (JOURNEY_LENGTH + 60);
      const side = rand() < 0.5 ? -1 : 1;
      const s = 6 + rand() * 16;
      return { pos: [pathX(d) + side * (12 + rand() * 30), pathY(d) - 4 + (rand() - 0.5) * 16, -d] as [number, number, number], s, fall: rand() < 0.6, bob: rand() * 6 };
    });
  }, []);
  const group = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    group.current?.children.forEach((c, i) => { c.position.y = islands[i]!.pos[1] + Math.sin(clock.elapsedTime * 0.3 + islands[i]!.bob) * 0.4; });
  });
  return <group ref={group}>
    {islands.map((it, i) => <Billboard key={i} position={it.pos}>
      <mesh scale={[it.s, it.s, 1]}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial map={island} transparent depthWrite={false} toneMapped={false} />
      </mesh>
      {it.fall && <group position={[it.s * 0.08, -it.s * 0.08, -0.05]}><Waterfall height={it.s * 1.4} /></group>}
    </Billboard>)}
  </group>;
}

function Mountains() {
  const peaks = useMemo(() => {
    const rand = seeded(99);
    return Array.from({ length: 26 }, () => {
      const d = rand() * (JOURNEY_LENGTH + 200);
      const side = rand() < 0.5 ? -1 : 1;
      const h = 30 + rand() * 45;
      return { pos: [pathX(d) + side * (60 + rand() * 50), -38 + h / 2, -d - 60] as [number, number, number], h, r: h * (0.45 + rand() * 0.3) };
    });
  }, []);
  return <>{peaks.map((p, i) => <mesh key={i} position={p.pos}>
    <coneGeometry args={[p.r, p.h, 6]} />
    <meshStandardMaterial color="#6f8aa6" roughness={0.95} flatShading />
  </mesh>)}</>;
}

function Birds({ paused }: { paused: boolean }) {
  const flocks = useMemo(() => {
    const rand = seeded(5);
    return Array.from({ length: 12 }, () => {
      const d = 20 + rand() * JOURNEY_LENGTH;
      return { base: [pathX(d) + (rand() - 0.5) * 30, pathY(d) + 5 + rand() * 9, -d] as [number, number, number], speed: 0.8 + rand() * 1.2, phase: rand() * 10 };
    });
  }, []);
  const geom = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute([-0.5, 0.12, 0, 0, 0, 0, -0.05, -0.05, 0, 0.5, 0.12, 0, 0, 0, 0, 0.05, -0.05, 0], 3));
    return g;
  }, []);
  const refs = useRef<(THREE.Group | null)[]>([]);
  const time = useRef(0);
  useFrame((_, dt) => {
    if (!paused) time.current += Math.min(dt, 0.05);
    flocks.forEach((f, i) => {
      const g = refs.current[i];
      if (!g) return;
      const t = time.current;
      g.position.set(f.base[0] + ((t * f.speed + f.phase) % 40) - 20, f.base[1] + Math.sin(t * 0.5 + f.phase) * 0.8, f.base[2]);
      g.children.forEach((b, j) => { b.scale.y = Math.sin(t * 7 + j * 1.3 + f.phase) * 1.4; });
    });
  });
  return <>{flocks.map((_, i) => <group key={i} ref={(el) => { refs.current[i] = el; }}>
    {([[0, 0], [-0.9, -0.5], [0.9, -0.5], [-1.8, -1], [1.8, -1]] as const).map(([x, y], j) => <mesh key={j} geometry={geom} position={[x, y, 0]} scale={0.7}>
      <meshBasicMaterial color="#2d3b4a" side={THREE.DoubleSide} />
    </mesh>)}
  </group>)}</>;
}

function AmbientMotes({ distanceRef }: { distanceRef: MutableRefObject<number> }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(() => { if (ref.current) { const d = distanceRef.current; ref.current.position.set(pathX(d), pathY(d), -d - 4); } });
  return <group ref={ref}><Sparkles count={60} scale={[30, 16, 30]} size={2.4} speed={0.25} opacity={0.7} color="#fff5d6" /></group>;
}

function Sun() {
  const tex = useMemo(() => makeCanvasTexture((ctx, w, h) => {
    const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
    g.addColorStop(0, "rgba(255,252,235,1)"); g.addColorStop(0.15, "rgba(255,236,190,0.8)"); g.addColorStop(0.5, "rgba(255,214,150,0.18)"); g.addColorStop(1, "rgba(255,210,150,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
  }), []);
  const { camera } = useThree();
  const ref = useRef<THREE.Mesh>(null);
  useFrame(() => { if (ref.current) { ref.current.position.set(camera.position.x + 40, camera.position.y + 26, camera.position.z - 120); ref.current.lookAt(camera.position); } });
  return <mesh ref={ref} scale={70}><planeGeometry args={[1, 1]} /><meshBasicMaterial map={tex} transparent depthWrite={false} fog={false} toneMapped={false} /></mesh>;
}

function World(props: Props) {
  const distanceRef = useRef(props.targetRef.current);
  return <>
    <fog attach="fog" args={["#cfe0ee", 45, 230]} />
    <ambientLight intensity={1.4} />
    <hemisphereLight args={["#d7edff", "#cf9d73", 1.4]} />
    <directionalLight position={[30, 30, 10]} intensity={2} color="#fff3d7" />
    <Environment><Lightformer intensity={2} position={[0, 6, 2]} scale={[15, 10, 1]} /><Lightformer intensity={1} color="#adcfea" position={[-6, 2, -1]} scale={[15, 8, 1]} /></Environment>
    <Sun />
    <Birds paused={props.paused} />
    <AmbientMotes distanceRef={distanceRef} />
    <Suspense fallback={null}>
      <Clouds />
      <Islands />
      {destinations.map((item) => <Portal key={item.id} item={item} enter={props.enter} />)}
      <FlightRig targetRef={props.targetRef} paused={props.paused} distanceRef={distanceRef} />
      {/* Compile every shader and upload every texture up front, so nothing hitches mid-flight. */}
      <Preload all />
    </Suspense>
  </>;
}

export function SkyScene(props: Props) {
  return <div className="sky-canvas" aria-label="A long flight through the sky past six floating portfolio doors">
    <Canvas camera={{ position: [0, 1, 10], fov: 55, near: 0.1, far: 400 }} dpr={[1, 1.5]} gl={{ alpha: true, antialias: true, powerPreference: "high-performance" }} performance={{ min: 0.6 }} style={{ background: "transparent" }}>
      <World {...props} />
      <AdaptiveDpr />
    </Canvas>
  </div>;
}
