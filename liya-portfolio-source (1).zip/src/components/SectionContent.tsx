import { useState } from "react";
import { ArrowLeft, ArrowRight, Mail } from "lucide-react";
import { githubPath, linkedinPath } from "@/lib/contact-icons";
import { about, achievements, beyond, contactLinks, education, projects, skills, type DestinationId } from "@/lib/portfolio";

function Projects() {
  const [openId, setOpenId] = useState<string | null>(null);
  const open = projects.find((p) => p.id === openId);
  if (!open) {
    return <div className="project-cards" key="list">
      {projects.map((p, i) => <button type="button" key={p.id} className="glass-card project-card" onClick={() => setOpenId(p.id)}>
        <small>PROJECT {String(i + 1).padStart(2, "0")}</small>
        <h3>{p.name}</h3>
        <p className="card-sub">{p.subtitle}</p>
        <p>{p.oneLiner}</p>
        <span className="card-cta">View Project <ArrowRight size={15} /></span>
      </button>)}
    </div>;
  }
  return <div className="project-detail" key={open.id}>
    <button type="button" className="back-link" onClick={() => setOpenId(null)}><ArrowLeft size={15} /> Back to Projects</button>
    <div className="glass-card"><small>OVERVIEW</small><h3>{open.name}</h3><p className="card-sub">{open.subtitle}</p><p>{open.overview}</p></div>
    <div className="glass-card"><small>TECHNOLOGIES</small>
      {open.technologies.length ? <div className="chip-row">{open.technologies.map((t) => <span className="skill-orb" key={t}>{t}</span>)}</div> : <p className="muted">To be updated.</p>}
    </div>
    <div className="glass-card"><small>FEATURES</small><ul className="feature-list">{open.features.map((f) => <li key={f}>{f}</li>)}</ul></div>
    <div className="glass-card"><small>{open.rolesLabel.toUpperCase()}</small><div className="chip-row">{open.roles.map((r) => <span className="skill-orb" key={r}>{r}</span>)}</div></div>
  </div>;
}

export function SectionContent({ id }: { id: DestinationId }) {
  if (id === "about") return <div className="section-prose">
    <div className="glass-card"><h3 className="person-name">{about.name}</h3><p className="card-sub">{about.role}</p><p>{about.intro}</p></div>
  </div>;
  if (id === "skills") return <div className="card-grid">{skills.map((s) => <span className="glass-card skill-card" key={s}>{s}</span>)}</div>;
  if (id === "projects") return <Projects />;
  if (id === "education") return <div className="card-stack">
    {education.map((e) => <div className="glass-card" key={e.title}><small>EDUCATION</small><h3>{e.title}</h3><p>{e.detail}</p></div>)}
    {achievements.length
      ? achievements.map((a) => <div className="glass-card" key={a.title}><small>ACHIEVEMENT</small><h3>{a.title}</h3><p>{a.detail}</p></div>)
      : <div className="glass-card is-placeholder"><small>ACHIEVEMENTS & CERTIFICATIONS</small><p className="muted">To be added soon.</p></div>}
  </div>;
  if (id === "beyond") return <div className="card-grid is-wide">{beyond.map((b) => <span className="glass-card skill-card" key={b}>{b}</span>)}</div>;
  return <div className="contact-content">
    <p className="lead">{about.name}</p>
    <div className="contact-links">{contactLinks.map(({ label, href, detail, icon }) => <a key={label} href={href} target={href.startsWith("https") ? "_blank" : undefined} rel={href.startsWith("https") ? "noopener noreferrer" : undefined} aria-label={`${label}: ${detail}`}>
      <span className="contact-icon">{icon !== "mail" ? <svg viewBox="0 0 24 24" width="25" height="25" role="img" aria-hidden="true"><path fill="currentColor" d={icon === "github" ? githubPath : linkedinPath} /></svg> : <Mail size={25} strokeWidth={1.7} />}</span>
      <span><strong>{label}</strong><small>{detail}</small></span>
      <span className="contact-tooltip" aria-hidden="true">{label}</span><ArrowRight size={17} />
    </a>)}</div>
  </div>;
}
