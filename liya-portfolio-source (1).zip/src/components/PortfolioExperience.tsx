import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Menu, Mouse, Pause, Play, Volume2, VolumeX, X } from "lucide-react";

import { SectionContent } from "./SectionContent";
import { Button } from "@/components/ui/button";
import { SkyScene } from "./SkyScene";
import { destinations, ENDING_DISTANCE, JOURNEY_LENGTH, VH_PER_UNIT, type DestinationId } from "@/lib/portfolio";
import { AmbientMusic } from "@/lib/ambient-music";
import skyImage from "@/assets/sky-world.jpg";

type Panel = DestinationId | "ending" | null;
const PANEL_START = 17; // shown just after flying through a door
const PANEL_END = 60;  // then she keeps flying and the panel fades away

function stateAt(d: number): { panel: Panel; approaching: DestinationId | null } {
  if (d >= ENDING_DISTANCE) return { panel: "ending", approaching: null };
  for (const item of destinations) {
    if (d >= item.distance + PANEL_START && d < item.distance + PANEL_END) return { panel: item.id, approaching: null };
  }
  const nextDoor = destinations.find(item => item.distance + PANEL_START > d);
  return { panel: null, approaching: nextDoor && d > 4 ? nextDoor.id : null };
}

export function PortfolioExperience() {
  const targetRef = useRef(0);
  const [distance, setDistance] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [paused, setPaused] = useState(false);
  const [dismissed, setDismissed] = useState<Panel>(null);
  const [musicOn, setMusicOn] = useState(false);
  const musicRef = useRef<AmbientMusic | null>(null);
  const meterRef = useRef<HTMLSpanElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const parallaxRef = useRef<HTMLDivElement>(null);
  const [volume, setVolume] = useState(0.6);
  const lastRef = useRef(-1);
  const toggleMusic = () => {
    musicRef.current ??= new AmbientMusic();
    if (musicOn) musicRef.current.stop(); else musicRef.current.start(volume);
    setMusicOn(!musicOn);
  };

  const flyTo = useCallback((d: number) => {
    setMenuOpen(false);
    const max = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: (d / JOURNEY_LENGTH) * max, behavior: "smooth" });
  }, []);
  const goTo = useCallback((id: DestinationId) => { const item = destinations.find(d => d.id === id)!; flyTo(item.distance + PANEL_START + 2); }, [flyTo]);
  const home = useCallback(() => flyTo(0), [flyTo]);

  useEffect(() => {
    const onScroll = () => {
      const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const d = (window.scrollY / max) * JOURNEY_LENGTH;
      targetRef.current = d;
      // Only re-render when the coarse value changes; the 3D flight reads targetRef every frame.
      if (meterRef.current) meterRef.current.style.transform = `scaleX(${d / JOURNEY_LENGTH})`;
      if (parallaxRef.current) parallaxRef.current.style.transform = `translate3d(${(-d / JOURNEY_LENGTH) * 10}%, 0, 0)`;
      const coarse = Math.round(d);
      if (coarse !== lastRef.current) { lastRef.current = coarse; setDistance(coarse); }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("resize", onScroll); };
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setMenuOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const { panel: rawPanel, approaching } = stateAt(distance);
  const panel = rawPanel === dismissed ? null : rawPanel;
  useEffect(() => { if (rawPanel !== dismissed) setDismissed(null); }, [rawPanel, dismissed]);
  const index = destinations.findIndex(d => d.id === rawPanel);
  const current = destinations[index];
  const activeIndex = rawPanel === "ending" ? destinations.length : destinations.filter(d => distance >= d.distance).length;
  const next = () => { const following = destinations[index + 1]; if (rawPanel === "ending") home(); else if (following) goTo(following.id); else flyTo(ENDING_DISTANCE + 8); };
  const previous = () => { if (rawPanel === "ending") goTo("contact"); else if (index <= 0) home(); else goTo(destinations[index - 1]!.id); };
  const atHome = distance < 6;
  useEffect(() => { musicRef.current?.setMood(approaching && destinations.find(d => d.id === approaching)!.distance - distance < 25 ? 1 : panel ? 0.4 : 0); }, [approaching, distance, panel]);

  return <main className="experience" style={{ height: `calc(${JOURNEY_LENGTH * VH_PER_UNIT}vh + 100svh)` }}>
    <div className="journey-stage" ref={stageRef}>
      <div className="sky-parallax" ref={parallaxRef}><div className="sky-backdrop" style={{ backgroundImage: `url(${skyImage})` }} /></div>
      <div className="sun-rays" />
      <div className="sky-atmosphere" />
      <SkyScene targetRef={targetRef} paused={paused} enter={goTo} />
      <header className="site-header">
        <Button variant="skyGhost" size="icon" className="brand-mark" onClick={home} aria-label="Return home"><span className="compass-mark">✧</span></Button>
        <Button variant="skyGhost" className="brand-name" onClick={home}>LIYA</Button>
        <Button variant="skyOutline" className="menu-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label={menuOpen ? "Close menu" : "Open menu"}>{menuOpen ? <X size={16} /> : <Menu size={16} />}<span>Menu</span></Button>
        <Button variant="skyOutline" size="icon" className="flight-toggle" onClick={() => setPaused(value => !value)} aria-label={paused ? "Resume flight" : "Pause flight"} title={paused ? "Resume flight" : "Pause flight"}>{paused ? <Play size={16} /> : <Pause size={16} />}</Button>
        <div className="music-control">
          {musicOn && <input type="range" className="volume-slider" min={0} max={1} step={0.01} value={volume} aria-label="Music volume" onChange={(e) => { const v = Number(e.target.value); setVolume(v); musicRef.current?.setVolume(v); }} />}
          <Button variant="skyOutline" size="icon" className="flight-toggle" onClick={toggleMusic} aria-label={musicOn ? "Music off" : "Music on"} title={musicOn ? "Music off" : "Music on"}>{musicOn ? <Volume2 size={16} /> : <VolumeX size={16} />}</Button>
        </div>
      </header>

      {atHome && <section className="home-intro" aria-label="Welcome">
        <h1>MY JOURNEY</h1>
        <h2>A Portfolio Through the Sky</h2>
        <div className="intro-rule" />
        <p className="intro-name">Liya Fathima</p>
        <p className="intro-status">MCA Student</p>
        <div className="intro-decoration"><span />✦<span /></div>
        <Button variant="skyOutline" size="lg" className="start-button" onClick={() => flyTo(14)}>Start Journey <ArrowRight size={18} /></Button>
      </section>}

      {!panel && approaching && <div className="travel-indicator" aria-live="polite">FLYING TOWARD {destinations.find(d => d.id === approaching)?.title} <span>✧</span></div>}

      {panel && <section className="destination-view" key={panel} aria-label={panel === "ending" ? "Journey ending" : current?.title}>
        <div className={`destination-sheet${panel === "ending" ? " is-ending" : ""}`}>
          <div className="sheet-heading"><span className="section-index">{panel === "ending" ? "07 / THE JOURNEY CONTINUES" : `${String(index + 1).padStart(2, "0")} / THE JOURNEY`}</span><Button variant="skyGhost" size="icon" onClick={() => setDismissed(panel)} aria-label="Hide section"><X size={20} /></Button></div>
          <h2>{panel === "ending" ? "THANK YOU FOR EXPLORING MY JOURNEY" : current?.title}</h2>
          {panel === "ending" ? <p className="lead">Dream • Build • Grow</p> : <SectionContent id={panel} />}
          <div className="sheet-actions"><Button variant="skyGhost" onClick={previous}><ArrowLeft size={16} /> {panel === "about" ? "Back to start" : "Previous"}</Button><Button variant="skyOutline" onClick={next}>{panel === "ending" ? "Fly home" : panel === "contact" ? "Final flight" : "Keep flying"}<ArrowRight size={16} /></Button></div>
        </div>
      </section>}

      {menuOpen && <nav className="journey-menu" aria-label="Journey menu"><span className="menu-eyebrow">CHOOSE A DESTINATION</span><Button variant="skyGhost" onClick={home}>Home</Button>{destinations.map((item, i) => <Button variant="skyGhost" key={item.id} onClick={() => goTo(item.id)}><small>{String(i + 1).padStart(2, "0")}</small>{item.title}</Button>)}</nav>}
      <footer className="site-footer"><div className="footer-motto"><span className="footer-star">✧</span><span>Dream&nbsp; • &nbsp;Build&nbsp; • &nbsp;Grow</span></div>{atHome && <div className="scroll-cue"><span>Scroll to begin the journey</span><Mouse size={24} strokeWidth={1.3} /><span className="scroll-line" /></div>}<div className="journey-progress" aria-label="Journey progress">{destinations.map((d, i) => <Button variant="skyGhost" size="icon" key={d.id} title={d.title} aria-label={`Fly to ${d.title}`} onClick={() => goTo(d.id)} className={activeIndex === i + 1 ? "is-active" : ""}><span>{i + 1}</span></Button>)}</div><div className="flight-meter" aria-hidden="true"><span ref={meterRef} /></div></footer>
    </div>
  </main>;
}
