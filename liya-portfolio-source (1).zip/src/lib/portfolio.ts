import { BookOpen, Brain, Code2, Compass, Mail, UserRound } from "lucide-react";

/** `distance` = how far along the flight path (world units) each door stands. Gaps are intentionally huge. */
export const destinations = [
  { id: "about", title: "ABOUT ME", icon: UserRound, color: "#91e4ff", distance: 80 },
  { id: "skills", title: "SKILLS", icon: Brain, color: "#d8a8ff", distance: 175 },
  { id: "projects", title: "PROJECTS", icon: Code2, color: "#8bdcff", distance: 290 },
  { id: "education", title: "EDUCATION & ACHIEVEMENTS", icon: BookOpen, color: "#ffe5ae", distance: 405 },
  { id: "beyond", title: "BEYOND CODING", icon: Compass, color: "#e8b9eb", distance: 500 },
  { id: "contact", title: "CONTACT", icon: Mail, color: "#b2f7f5", distance: 615 },
] as const;

/** Total flight length; the final thank-you appears near the end. */
export const JOURNEY_LENGTH = 760;
export const ENDING_DISTANCE = 715;
/** Scroll height per world unit (vh) — controls how much scrolling the flight takes. */
export const VH_PER_UNIT = 6;

export type DestinationId = (typeof destinations)[number]["id"];

export const contactLinks = [
  { label: "GitHub", href: "https://github.com/liya935", detail: "github.com/liya935", icon: "github" },
  { label: "LinkedIn", href: "https://linkedin.com/in/liya", detail: "linkedin.com/in/liya", icon: "linkedin" },
  { label: "Email", href: "mailto:liyafathimabinthsafeer@gmail.com", detail: "liyafathimabinthsafeer@gmail.com", icon: "mail" },
] as const;

/* ---------- Section content (edit here) ---------- */
export const about = {
  name: "Liya Fathima",
  role: "MCA Student",
  intro: "I’m an MCA student who enjoys software development, creative problem-solving and building useful applications. I love learning new technologies and turning ideas into practical, thoughtful software.",
};

export const skills = ["C", "Python", "Java", "HTML", "CSS", "JavaScript", "Kotlin", "SQL", "Git", "GitHub", "VS Code"];

export type Project = {
  id: string;
  name: string;
  subtitle: string;
  oneLiner: string;
  overview: string;
  technologies: string[];
  features: string[];
  roles: string[];
  rolesLabel: string;
};

export const projects: Project[] = [
  {
    id: "scrapick",
    name: "ScraPick",
    subtitle: "Smart Waste Management System",
    oneLiner: "Connecting citizens, collectors and admins for smarter waste collection.",
    overview: "A smart waste management system that connects citizens, waste collectors and administrators to improve waste collection and management.",
    technologies: ["Kotlin", "Android", "Node.js", "Database"],
    features: ["Waste pickup requests", "Waste collection management", "Complaint/reporting system", "Waste disposal information", "Admin dashboard", "Collector task management", "EcoMart marketplace"],
    rolesLabel: "Roles",
    roles: ["Customer", "Haritha Karma Sena / Collector", "Admin"],
  },
  {
    id: "academic",
    name: "AI Based Academic Workload Balancing and Smart Academic Scheduling System",
    subtitle: "Smart academic scheduling",
    oneLiner: "Balancing student workload with AI-assisted scheduling.",
    overview: "An AI-based academic system that helps manage student workload, activities, deadlines, scheduling and academic performance.",
    // Editable: add the final technologies here when decided.
    technologies: [],
    features: ["AI-based academic workload analysis", "Assignment and activity scheduling", "Daily workload limit", "Automatic blocking when workload limit is reached", "Smart alternative date suggestion", "Deadline conflict detection", "Exam and assignment calendar", "Student performance analysis", "Assignment scores", "Weak-area identification", "AI learning support", "Tutor study-material upload", "Student assignment submission", "AI chatbot based on tutor-uploaded study materials"],
    rolesLabel: "Modules",
    roles: ["Tutor", "Student", "AI learning assistant"],
  },
];

export const education = [
  { title: "MCA", detail: "Currently Pursuing" },
  { title: "B.Sc Computer Science", detail: "Farook College" },
];
/** Editable: add real achievements / certifications here. Left empty on purpose — never invent entries. */
export const achievements: { title: string; detail: string }[] = [];

export const beyond = ["Creativity", "Design", "Learning", "Ideas", "Exploration"];
