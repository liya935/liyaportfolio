/** The winding sky route. Distance d maps to a world point at z = -d. */
export function pathX(d: number) {
  return Math.sin(d * 0.011) * 7 + Math.sin(d * 0.029 + 1.3) * 2.2;
}
export function pathY(d: number) {
  return Math.sin(d * 0.016 + 0.4) * 2.6 + Math.sin(d * 0.041) * 0.6;
}

export function seeded(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
