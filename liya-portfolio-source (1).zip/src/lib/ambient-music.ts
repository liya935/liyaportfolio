/** Original generative ambient score (Web Audio). Soft pad chords + sparkling bell notes; `setMood` swells gently near doors. */
const CHORDS = [
  [220, 277.18, 329.63, 415.3],
  [196, 246.94, 293.66, 369.99],
  [174.61, 220, 261.63, 329.63],
  [196, 246.94, 329.63, 392],
];
const BELLS = [659.25, 739.99, 830.61, 987.77, 1108.73];

export class AmbientMusic {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private bellGain: GainNode | null = null;
  private timers: number[] = [];
  playing = false;

  private volume = 0.6;

  start(volume = this.volume) {
    this.volume = volume;
    if (!this.ctx) this.build();
    void this.ctx!.resume();
    this.master!.gain.cancelScheduledValues(this.ctx!.currentTime);
    this.master!.gain.setTargetAtTime(this.gainFor(volume), this.ctx!.currentTime, 0.8);
    this.playing = true;
  }

  /** 0..1 user volume; 0.6 ≈ comfortably audible. */
  setVolume(volume: number) {
    this.volume = volume;
    if (this.ctx && this.master && this.playing) this.master.gain.setTargetAtTime(this.gainFor(volume), this.ctx.currentTime, 0.15);
  }

  private gainFor(v: number) { return v * 1.6; }

  stop() {
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(0, this.ctx.currentTime, 0.6);
    this.playing = false;
  }

  /** 0 = calm flight, 1 = approaching a door. Changes are slow to avoid jumps. */
  setMood(level: number) {
    if (!this.ctx || !this.bellGain) return;
    this.bellGain.gain.setTargetAtTime(0.08 + level * 0.12, this.ctx.currentTime, 2.5);
  }

  private build() {
    const ctx = new AudioContext();
    this.ctx = ctx;
    const master = ctx.createGain();
    master.gain.value = 0;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1400;
    const delay = ctx.createDelay(2);
    delay.delayTime.value = 0.45;
    const feedback = ctx.createGain();
    feedback.gain.value = 0.4;
    delay.connect(feedback).connect(delay);
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 4;
    filter.connect(master);
    filter.connect(delay);
    delay.connect(master);
    master.connect(comp).connect(ctx.destination);
    this.master = master;
    const bellGain = ctx.createGain();
    bellGain.gain.value = 0.08;
    bellGain.connect(filter);
    this.bellGain = bellGain;

    let chord = 0;
    const playChord = () => {
      const now = ctx.currentTime;
      CHORDS[chord % CHORDS.length]!.forEach((f, i) => {
        for (const detune of [-6, 6]) {
          const o = ctx.createOscillator();
          o.type = i === 0 ? "sine" : "triangle";
          o.frequency.value = f;
          o.detune.value = detune;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, now);
          g.gain.linearRampToValueAtTime(0.05, now + 3);
          g.gain.linearRampToValueAtTime(0, now + 9.5);
          o.connect(g).connect(filter);
          o.start(now);
          o.stop(now + 10);
        }
      });
      chord++;
    };
    const playBell = () => {
      const now = ctx.currentTime;
      const o = ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = BELLS[Math.floor(Math.random() * BELLS.length)]!;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, now);
      g.gain.linearRampToValueAtTime(0.5, now + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, now + 3);
      o.connect(g).connect(bellGain);
      o.start(now);
      o.stop(now + 3.1);
    };
    playChord();
    this.timers.push(window.setInterval(playChord, 8000));
    this.timers.push(window.setInterval(() => { if (Math.random() < 0.6) playBell(); }, 1700));
  }
}
